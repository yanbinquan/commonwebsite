﻿namespace CommonWebsite.Data.Entities
{
    public class User
    {
        public int Id { set; get; }
        public string Name { get; set; }
    }
}