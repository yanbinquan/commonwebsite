﻿namespace CommonWebsite.Infrastructure.Logging
{
    public interface ILogger
    {
        void Log(object message);
    }
}
